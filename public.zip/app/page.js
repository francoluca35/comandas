import Login from "./login/page";
import RegisterPage from "./register/page";

export default function Home() {
  return (
    <main>
      <Login />
    </main>
  );
}
