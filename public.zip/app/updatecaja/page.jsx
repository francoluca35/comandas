import React from "react";
import CajaRetiro from "./components/CajaRetiro";

function updatecaja() {
  return (
    <div>
      <CajaRetiro />
    </div>
  );
}

export default updatecaja;
