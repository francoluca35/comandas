import React from "react";
import ForgotPassword from "./components/ForgotPassword";

function recuperar() {
  return (
    <div>
      <ForgotPassword />
    </div>
  );
}

export default recuperar;
